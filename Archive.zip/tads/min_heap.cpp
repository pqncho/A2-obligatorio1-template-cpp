#pragma once 

#include <cassert>
#include "heap.cpp"

template <class T> class minHeap : public heap<T> {
    private:
        T* arr;
        int arrLength;
        int ix;
       

        void swap(int posA, int posB) {
            T aux = this->arr[posA];
            this->arr[posA] = this->arr[posB];
            this->arr[posB] = aux;
        }

        void siftUp(int pos) {
            if(pos == 1) return;

            //comparo con el padre
            int pPos = pos/2;
            T elem = this->arr[pos];
            T parent = this->arr[pPos];

            if(parent > elem) {
                swap(pos, pPos);
                siftUp(pPos);
            }
        }

        void siftDown(int pos) {
            if(pos >= this->ix || pos >= this->arrLength) return;
            if((2*pos) > this->ix) return;
            T leftSon = this->arr[2*pos];
            T parent = this->arr[pos];
        
            if((pos*2)+1 > this->ix ){

                if(parent > leftSon) {
                    swap(pos , pos*2);
                    siftDown(pos*2); //podria no ir
                }
            }else {
                T rightSon = this->arr[2*pos +1];
                if(parent > leftSon || parent > rightSon){
                
                    if(leftSon <= rightSon) {
                        swap(pos, 2*pos);
                        siftDown(2*pos);
                    } else {
                        if(rightSon < leftSon){
                            swap(pos, 2*pos + 1);
                            siftDown(2*pos + 1);
                        }
                    }
                }
            }  
        }
        

        T remove() {
            T data = this->arr[1];
            swap(1, this->ix);
            this->ix--;
            siftDown(1);
            
            return data;
        }
    
    
    public:
        minHeap(int size) {
            this->arr = new T[size + 1]();
            this->arrLength = size + 1;
            this->ix = 0;
            
        }

        virtual void push(T elem) override { 
            this->ix++;
            this->arr[this->ix] = elem;
            siftUp(this->ix);    
        }
        
        virtual T top() override { 
            assert(size() >= 1);
            return this->arr[1]; 
        }
        virtual T pop() override { return remove(); }
        virtual int size() override { return this->ix; }
        virtual bool isEmpty() override { return this->ix == 0; }
        
};
