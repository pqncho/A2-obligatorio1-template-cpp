#pragma once


template <class K, class V> class table {
public:
    virtual void set(V value) = 0;
    //virtual bool exists(K key) = 0;
    virtual int get(K key) = 0;
    //virtual int size() = 0;
    virtual int getMaxBox() = 0;
    virtual int getFilledBoxes() = 0;
};